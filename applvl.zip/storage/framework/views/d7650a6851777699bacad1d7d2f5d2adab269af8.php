<?php $__env->startSection('content'); ?>
    <div class="row mt-5">
        <div class="col-xl-8 mb-5 mb-xl-0">
            <div class="card shadow">
                <div class="card-header border-0">
                    <div class="row align-items-center">
                        <div class="col">
                            <h3 class="mb-0">Médicos</h3>
                        </div>
                        <div class="col text-right">
                            <a href="<?php echo e(url('/doctors/create')); ?>" class="btn btn-sm btn-success">Nuevo médico</a>
                        </div>
                    </div>
                </div>
                <?php if(session('notification')): ?>
                    <div class="card-body">
                        <div class="alert alert-success" role="alert">
                            <strong><?php echo e(session('notification')); ?></strong>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <!-- Projects table -->
                    <table class="table align-items-center table-flush">
                        <thead class="thead-light">
                        <tr>
                            <th scope="col">Nombre</th>
                            <th scope="col">E-mail</th>
                            <th scope="col">DNI</th>
                            <th scope="col">Opciones</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row">
                                    <?php echo e($doctor->name); ?>

                                </th>
                                <td word-wrap:break-word>
                                    <p class="card-text"><?php echo e($doctor->email); ?></p>
                                </td>

                                <td word-wrap:break-word>
                                    <p class="card-text"><?php echo e($doctor->dni); ?></p>
                                </td>

                                <td>

                                    <form action="<?php echo e(url('/doctors/'.$doctor->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <a href="<?php echo e(url('/doctors/'.$doctor->id.'/edit')); ?>" class="btn btn-sm btn-primary">Editar</a>
                                        <button href="" class="btn btn-sm btn-outline-danger" type="submit">Eliminar</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-xl-4">
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\applvl\resources\views/doctors/index.blade.php ENDPATH**/ ?>